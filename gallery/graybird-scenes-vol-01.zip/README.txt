Graybird 场景图集 Vol.01
雨夜便利店 / 凌晨的泡面 / 月球露营 / 地铁观察
角色依据官方三视图制作；AI 辅助生成场景插画。
https://graybird.space/gallery/
